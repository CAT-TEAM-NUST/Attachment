<?php
@$username = $_POST['username'];
@$password = $_POST['password'];

if (preg_match("/drop|delete|truncate|insert|into|create|use|declare|set/i", $username) or preg_match("/drop|delete|truncate|insert|into|create|use|declare|set/i", $password)) {
  die('what do you want to do?');
}

if (preg_match("/tables|select|union|from|where|\/|<|=/", $username) or preg_match("/tables|select|union|from|where|\/|<|=/", $password)) {
  die('you are hacker');
}

if ($username and $password) {

  $con = mysqli_connect('db', 'user', 'test', 'ctf');

  if (mysqli_connect_errno()) {
    echo 'Connection failed: ' . mysqli_connect_error();
  }

  $result = mysqli_query($con, "SELECT * FROM PERSON WHERE username='$username'");

  $row = @mysqli_fetch_array($result);

  if ($row) {
    $res = mysqli_query($con, "SELECT * FROM PERSON WHERE password='$password'");

    $t = @mysqli_fetch_array($res);

    if ($t) {
      header('Location: http://'.$_SERVER['HTTP_HOST'].'/query.php');  
      exit;
    }
    else {
      die('password wrong');
    }
  } else {
    die('username wrong');
  }
}

echo "<form action=index.php method=POST> <input name=username value=''> <br> <input name=password type=password value=''> <br> <input type=submit value='login'/></br>";
