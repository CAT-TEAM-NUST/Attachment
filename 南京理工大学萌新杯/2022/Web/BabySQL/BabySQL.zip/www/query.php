<?php
@$sql=$_POST['sql'];

if (preg_match("/drop|delete|truncate|insert|into|create|use|declare|set/i", $sql)) {
  die('what do you want to do?');
}

if (preg_match("/select|union|from|where|\/|<|\*/", $sql)) {
	die('you are hacker');
}

echo "<p>Your SQL</p> <form action=query.php method=POST> <input name=sql value=\"".$sql."\" style='width:50%'> <input type=submit value='submit'/> <br>";

$con = mysqli_connect('db', 'user', 'test', 'ctf');

if (mysqli_connect_errno()) {
    echo 'Connection failed: ' . mysqli_connect_error();
}

if ($sql != NULL) {

  $result = mysqli_query($con, $sql);

  $row = @mysqli_fetch_array($result);

  var_dump($row);
}