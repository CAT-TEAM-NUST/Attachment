const express = require('express')
const fs = require('fs')
var session = require("express-session")
const app = express()
const port = 3000
app.use(express.static(__dirname + '/static'))

app.use(session({
        secret: 'xss learn',
        resave: true,
        saveUninitialized: true
    }))

const template_arr = {
	"1":"reflect_xss.html",
	"2":"reflect_xss2.html",
	"3":"dom_xss.html",
	"4":"dom_xss2.html",
	"5":"dom_xss3.html",
	"6":"win.html"
}

app.get('/', (req, res) => res.sendfile('./static/index.html'))
app.get('/level:levelid',(req,res) =>{
	var levelid = req.params.levelid;
	var static_path = "static/" + template_arr[levelid];
	fs.exists(static_path, function(exists){
		if(exists){
			var template = fs.readFileSync(static_path);
			res.send(getResponse(levelid,template.toString(),req,res));
		}else{
			res.send('404');
		}
	})

})
app.post('/resetGame',(req,res) => {
	req.session.data = "";
	res.send('{"status":0}');
})

app.listen(port, () => console.log(`xss app listening on port ${port}!`))

function getResponse(levelid,template,req,res){
	switch (levelid){
		case "1":
			var HTML = template.replace(/##username##/,req.query.username);
			res.header('X-XSS-Protection','0');
			break;
		case "2":
			var HTML = template.replace(/##username##/,req.query.username);
			break;
		case "3":
			if(typeof(req.query.username) == 'undefined'){
				var username = "";
			}else{
				var username = req.query.username.replace(/'/,"\\'");
			}
			
			var HTML = template.replace(/##username##/,username);
			break;
		case "4":
			var HTML = template;
			break;
		case "5":
			var HTML = template;
			break;
		case "6":
			if(typeof(req.query.username) == 'undefined'){
				var username = "";
			}else{
				var username = req.query.username.replace(/</g,'&#x3c;');
			}
			var HTML = template.replace(/##username##/,username);
			break;
		case "7":
			var HTML = template;
			break;
	}
	return HTML;
}