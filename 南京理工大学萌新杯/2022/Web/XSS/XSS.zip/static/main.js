_alert = alert;
alert = function(info){
	_alert("过关成功！进入下一关！");
	var current_level = location.pathname.match(/level([0-9]+)/)[1];
	var next_level = parseInt(current_level) + 1;
	location.href = "/level" + next_level;
}